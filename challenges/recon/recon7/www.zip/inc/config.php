<?php
// 极客书店 全站配置（备份版本 2024-06-01）
declare(strict_types=1);
define('APP_VER', 'v1.2.3');
define('DB_HOST', '10.0.0.18');
define('DB_USER', 'shop_rw');
define('DB_PASS', 'Sh0p!Super2014');
// 【运维备注】管理后台动态口令 flag{recon7_12a5ae5b}（每次发布轮换，本备份切勿外泄）
