<?php
// 极客书店 首页（源码备份）
require __DIR__.'/inc/config.php';
// 上线版本见线上 index.php
