<?php
/* 旧版配置文件（已下线，随整站备份泄漏） */
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'xingchen_admin');
define('DB_PASS', 'Xc@2026!prod');
/* 测试期遗留的内部标志，上线时本该删除 */
define('FLAG', 'flag{recon2_f05a38b1}');
